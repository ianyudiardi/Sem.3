﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplikasiInputDataMahasiswa
{
    class Mahasiswa
    {
        public string Nama { get; set; }
        public int Nilai { get; set; }
        public string Nim { get; set; }
        public string Kelas { get; set; }
    }
}
